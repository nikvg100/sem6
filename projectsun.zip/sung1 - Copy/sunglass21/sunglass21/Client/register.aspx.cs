﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
using System.Web.Configuration;

public partial class Client_register : System.Web.UI.Page
{
    public SqlConnection con;
    public SqlCommand cmd;
    public SqlDataAdapter da;

    protected void Page_Load(object sender, EventArgs e)
    {
        string con_string = WebConfigurationManager.ConnectionStrings["conn"].ConnectionString;
        con = new SqlConnection(con_string);
        con.Open();
    }
    protected void btn_register_Click(object sender, EventArgs e)
    {
        string fnm, lnm, city, email, password, mobileno, unm;
        unm = txt_usernm.Text;
        fnm = txt_fnm.Text;
        lnm = txt_lnm.Text;
        
        city = txt_city.Text;

        

        email = txt_emailid.Text;
        password = txt_password.Text;
        mobileno =txt_mobileno.Text;

        string qry = "insert into reg(l_name,f_name,city,mo_no,email,user_nm,password) values('" + lnm + "','" + fnm + "','" + city + "'," + mobileno + ",'" + email + "','" + unm + "','" + password + "')";
        cmd = new SqlCommand(qry, con);
        cmd.ExecuteNonQuery();

        Response.Write("<script> alert('Record Inserted Successfully');</script>");

        txt_city.Text  = txt_emailid.Text = txt_fnm.Text = txt_lnm.Text = txt_mobileno.Text = txt_password.Text = "";
    }
}
