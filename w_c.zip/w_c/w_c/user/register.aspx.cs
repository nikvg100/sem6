﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;



namespace w_c.user
{
    public partial class register : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            l1.Visible = false;
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
           // string n = ConfigurationManager.ConnectionStrings["nik"].ConnectionString.ToString();
        //SqlConnection con = new SqlConnection("n");
        //con.Open();
        //SqlCommand cmd = con.CreateCommand();
        //cmd.CommandType = CommandType.Text;
        //cmd.CommandText = "insert into reg values('" + t1.Text + "','" + t2.Text + "','" + t3.Text + "','" + t4.Text + "','" + t5.Text + "','" + t6.Text + "','" + t7.Text + "')";
       // cmd.ExecuteNonQuery();
        //con.Close();
        //t1.Visible = true;
        //t1.Text = "You are Registered successfullu ... click on Login ";

        string connectionString = ConfigurationManager.ConnectionStrings["nik"].ConnectionString.ToString();
        using (SqlConnection con = new SqlConnection(connectionString))
        {
            con.Open();

            using (SqlCommand cmd = con.CreateCommand())
            {
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "INSERT INTO reg VALUES(@t1, @t2, @t3, @t4, @t5, @t6, @t7)";

                // Use parameters to prevent SQL injection
                cmd.Parameters.AddWithValue("@t1", t1.Text);
                cmd.Parameters.AddWithValue("@t2", t2.Text);
                cmd.Parameters.AddWithValue("@t3", t3.Text);
                cmd.Parameters.AddWithValue("@t4", t4.Text);
                cmd.Parameters.AddWithValue("@t5", t5.Text);
                cmd.Parameters.AddWithValue("@t6", t6.Text);
                cmd.Parameters.AddWithValue("@t7", t7.Text);

                cmd.ExecuteNonQuery();

            }
            con.Close();
            // Set the text after the database operation
            l1.Visible = true;
            l1.Text = "You are Registered successfully... Click on Login";
            t1.Text = "";
            t2.Text = "";
            t3.Text = "";
            t4.Text = "";
            t5.Text = "";
            t6.Text = "";
            t7.Text = "";

        }
   
        
        }
    }
}