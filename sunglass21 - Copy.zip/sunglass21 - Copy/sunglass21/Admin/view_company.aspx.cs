﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Web.Configuration;

public partial class Admin_view_company : System.Web.UI.Page
{
    public SqlConnection con;
    public SqlCommand cmd;
    public SqlDataAdapter da;

    protected void Page_Load(object sender, EventArgs e)
    {
        string con_string = WebConfigurationManager.ConnectionStrings["conn"].ConnectionString;
        con = new SqlConnection(con_string);
        con.Open();

        if (!IsPostBack)
        {
            showgrid();
        }
    }
    void showgrid()
    {
        DataTable dt = new DataTable();
        string qry = "select * from tbl_company";
        da = new SqlDataAdapter(qry, con);
        da.Fill(dt);

        grd_v.DataSource = dt;
        grd_v.DataBind();
    }
    protected void grd_v_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        string id = grd_v.DataKeys[e.RowIndex].Values[0].ToString();
        int i = Convert.ToInt32(grd_v.DataKeys[e.RowIndex].Values[0]);

        cmd = new SqlCommand("DELETE FROM tbl_company WHERE c_Id='" + id + "'", con);
        cmd.ExecuteNonQuery();
        showgrid();

        con.Close();
        con.Dispose();
    }
    protected void grd_v_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        grd_v.PageIndex = e.NewPageIndex;
        showgrid();
    }
    protected void grd_v_RowEditing(object sender, GridViewEditEventArgs e)
    {
        grd_v.EditIndex = e.NewEditIndex;
        showgrid();
    }
    protected void grd_v_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        grd_v.EditIndex = -1;
        showgrid();
    }
    protected void grd_v_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        Label id = grd_v.Rows[e.RowIndex].FindControl("lbl_id") as Label;
        TextBox nm = grd_v.Rows[e.RowIndex].FindControl("txt_nm") as TextBox;
        TextBox des = grd_v.Rows[e.RowIndex].FindControl("txt_des") as TextBox;

        string qry = "update tbl_company set c_name='" + nm.Text + "',c_description='" + des.Text + "' where c_Id=" + Convert.ToInt32(id.Text);
        cmd = new SqlCommand(qry, con);
        cmd.ExecuteNonQuery();

        grd_v.EditIndex = -1;
        showgrid();

        Response.Redirect("view_company.aspx");
    }
}