﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
using System.Web.Configuration;

public partial class Client_login : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection();
    SqlDataAdapter da = new SqlDataAdapter();

   // public SqlConnection con;
   // public SqlDataAdapter da;
   // public DataTable dt;
    protected void Page_Load(object sender, EventArgs e)
    {
    }
    protected void btn_login_Click(object sender, EventArgs e)
    {
        string con_string = WebConfigurationManager.ConnectionStrings["conn"].ConnectionString;
        con = new SqlConnection(con_string);
        con.Open();
        SqlCommand cmd = new SqlCommand("select count(Id) from reg where user_nm='" + txt_usernm.Text + "' and password='" + txt_password.Text + "'", con);
        //da = new SqlDataAdapter("select count(Id) from Admin_login where Admin_name='"+t1.Text +"' and Password='"+t2.Text+"'",con);
        //DataSet ds = new DataSet();
        //da.Fill(ds);
        //int x=ds.Tables[0].Rows.Count;
        int x = (int)cmd.ExecuteScalar();
        Response.Write("Value of x is " + x);
        //string u;
        //string p;
        //u = ds.Tables[0].Rows[0]["Admin_name"].ToString();
        ///p = ds.Tables[0].Rows[0]["Password"].ToString();
        //if(u==t1.Text && p==t2.Text)
        if (x == 1)
        {
            Session["user_nm"] = txt_usernm.Text;
            Session["pass"] = txt_password.Text;

            Response.Redirect("Home.aspx");
        }
        else
        {
            Response.Redirect("login.aspx");
        }
    }
}