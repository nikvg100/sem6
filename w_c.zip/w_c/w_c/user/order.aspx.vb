﻿
Partial Class user_order
    Inherits System.Web.UI.Page

End Class
