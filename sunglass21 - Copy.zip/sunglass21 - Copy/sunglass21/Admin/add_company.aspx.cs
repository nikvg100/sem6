﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Web.Configuration;

public partial class Admin_add_company : System.Web.UI.Page
{
    SqlCommand cmd = new SqlCommand();
    SqlConnection con = new SqlConnection();
        
    protected void Page_Load(object sender, EventArgs e)
    {
        string con_string = WebConfigurationManager.ConnectionStrings["conn"].ConnectionString;
        con = new SqlConnection(con_string);
        con.Open();
       
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        
       
        string com_nm, com_des;

        com_nm = TextBox1.Text;
        com_des = TextBox2.Text;

        string qry = "insert into tbl_company(c_name,c_description) values('" + TextBox1.Text + "','" + TextBox2.Text + "')";
        cmd = new SqlCommand(qry, con);
        cmd.ExecuteNonQuery();

        Response.Write("<script> alert('Record Inserted Successfully');</script>");

        TextBox1.Text = "";
        TextBox2.Text = "";
        con.Close();
    }
}