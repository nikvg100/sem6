﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
using System.Web.Configuration;

public partial class Client_register : System.Web.UI.Page
{
    public SqlConnection con;
    public SqlCommand cmd;
    public SqlDataAdapter da;

    protected void Page_Load(object sender, EventArgs e)
    {
        string con_string = WebConfigurationManager.ConnectionStrings["conn"].ConnectionString;
        con = new SqlConnection(con_string);
        con.Open();
    }
    protected void btn_register_Click(object sender, EventArgs e)
    {
        string fnm, lnm, add1, city, state, country, gender, email, password, mobileno;
        int pincode;

        fnm = txt_fnm.Text;
        lnm = txt_lnm.Text;
        add1 = txt_add1.Text;
        
        city = txt_city.Text;
        state = txt_state.Text;
        country = txt_country.Text;

        if (rdbmale.Checked == true)
        {
            gender = rdbmale.Text;
        }
        else
        {
            gender = rdbfemale.Text;
        }

        email = txt_emailid.Text;
        password = txt_password.Text;

        pincode = Convert.ToInt32(txt_pincode.Text);
        mobileno =txt_mobileno.Text;

        string qry = "insert into tbl_registration(last_name,first_name,address,city,state,country,pincode,gender,mobile_no,email,password) values('" + lnm + "','" + fnm + "','" + add1 + "','" + city + "','" + state + "','" + country + "'," + pincode + ",'" + gender + "'," + mobileno + ",'" + email + "','" + password + "')";
        cmd = new SqlCommand(qry, con);
        cmd.ExecuteNonQuery();

        Response.Write("<script> alert('Record Inserted Successfully');</script>");

        txt_city.Text = txt_country.Text = txt_emailid.Text = txt_fnm.Text = txt_lnm.Text = txt_mobileno.Text = txt_password.Text = txt_pincode.Text = txt_state.Text = "";
    }
}
