﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
using System.Web.Configuration;


public partial class Client_credit_payment : System.Web.UI.Page
{
    public SqlConnection con;
    public SqlCommand cmd,cmd1;
    public SqlDataAdapter da;
    public DataTable dt;


    public DateTime date;
    
    public int price, s_Id;
    string qnty, nm, address, no, cart_Id,tot;

    protected void Page_Load(object sender, EventArgs e)
    {
        string con_string = WebConfigurationManager.ConnectionStrings["conn"].ConnectionString;
        con = new SqlConnection(con_string);
        con.Open();

        if (Session["emlid"] == null || Session["pass"] == null)
        {

            Response.Redirect("login.aspx");
        }
        else
        {
            nm = Session["usr"].ToString();

            address = Request.QueryString["add"].ToString();
            no = Request.QueryString["no"].ToString();
           // Response.Write("<script>alert('" + no + "');</script>");
               cart_Id = Request.QueryString["id"].ToString();
              // TextBox2.Text =no;
               String qry = "select * from tbl_cart where cart_Id=" + cart_Id;
                 da = new SqlDataAdapter(qry, con);
                 dt = new DataTable();
                 da.Fill(dt);
                 cart_Id =dt.Rows[0][0].ToString();
                tot = dt.Rows[0][10].ToString();
                 qnty = dt.Rows[0][6].ToString();
                 s_Id =  Convert.ToInt32(dt.Rows[0][7].ToString());
                // price = Convert.ToInt32(dt.Rows[0][3].ToString());


                
            date = DateTime.Today.Date;

        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        String qry1 = "insert into tbl_order(s_Id,cust_nm,order_date,total_payment,payment_method,address,contact_no,qty,card_holder,card_number,expiry_date,cvv_no)values(" + s_Id + ",'" + nm + "','" + date + "','" + tot + "',' credit_card ','" + address + "','" + no + "','" + qnty + "','"+TextBox1.Text+"','"+TextBox2.Text+"','"+TextBox3.Text+"','"+TextBox4.Text+"')";
        
        cmd = new SqlCommand(qry1, con);
        cmd.ExecuteNonQuery();
        string delete = "delete from tbl_cart where cart_Id=" + cart_Id;
        cmd1 = new SqlCommand(delete, con);
        cmd1.ExecuteNonQuery();
        Response.Write("<script>alert('Successfully Credit  Payment....Thank You');</script>");
        Response.Redirect("Home.aspx");
   }
}