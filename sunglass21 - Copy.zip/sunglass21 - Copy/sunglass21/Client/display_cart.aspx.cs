﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
using System.Web.Configuration;
public partial class Client_display_cart : System.Web.UI.Page
{
    public SqlConnection con;
    public SqlCommand cmd;
    public SqlDataAdapter da, da1;
    public DataTable dt;

    protected void Page_Load(object sender, EventArgs e)
    {
        string con_string = WebConfigurationManager.ConnectionStrings["conn"].ConnectionString;
        con = new SqlConnection(con_string);
        con.Open();

        //string id =Session["unm"].ToString();
        //string id = Request.QueryString["custid"].ToString();
        //string eml = Session["emlid"].ToString();
        //string id = Request.QueryString["custid"].ToString();
        // Session["id"] = id.ToString();
        /*id = Convert.ToInt32(Request.QueryString["eml"].ToString());
        string qry1 = "select * from tbl_registration where cust_id="+id;
        da1 = new SqlDataAdapter(qry1,con);
        DataTable dt = new DataTable();
        da1.Fill(dt);*/
        
        if (Session["emlid"] == null || Session["pass"] == null || Session["id"]==null)
        {

            Response.Redirect("login.aspx");
        }
        
        
       
       /* else
        {
            int id = Convert.ToInt32(Session["id"].ToString());
            String qry1 = "select first_name from tbl_registration where r_Id=" + id;
            da1 = new SqlDataAdapter(qry1, con);
            dt = new DataTable();
            da1.Fill(dt);
            String nm = dt.Rows[0][0].ToString();
            string qry = "select * from tbl_cart where cust_nm='" + nm + "'";
            da = new SqlDataAdapter(qry, con);
            DataTable dt1 = new DataTable();
            da.Fill(dt1);

            grd_v.DataSource = dt1;
            grd_v.DataBind();
        }*/
        if (!IsPostBack)
        {
            showgrid();
        }

    }
    /*protected void grd_v_SelectedIndexChanged(object sender, EventArgs e)
    {

    }*/
    protected void grd_v_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        string id = grd_v.DataKeys[e.RowIndex].Values[0].ToString();
        int i = Convert.ToInt32(grd_v.DataKeys[e.RowIndex].Values[0]);

        cmd = new SqlCommand("DELETE FROM tbl_cart WHERE cart_Id='" + id + "'", con);
        cmd.ExecuteNonQuery();
        showgrid();

        con.Close();
        con.Dispose();
    }
    protected void grd_v_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        grd_v.PageIndex = e.NewPageIndex;
        showgrid();
    }
    protected void grd_v_RowEditing(object sender, GridViewEditEventArgs e)
    {
        grd_v.EditIndex = e.NewEditIndex;
        showgrid();
    }
    protected void grd_v_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        grd_v.EditIndex = -1;
        showgrid();
    }
    protected void grd_v_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        string id = grd_v.DataKeys[e.RowIndex].Values[0].ToString();
        //Label id = grd_v.Rows[e.RowIndex].FindControl("lbl_id") as Label;
        TextBox qnty = grd_v.Rows[e.RowIndex].FindControl("qnty") as TextBox;
        Label price = grd_v.Rows[e.RowIndex].FindControl("Label3") as Label;
        int tot =Convert.ToInt32(qnty.Text) * Convert.ToInt32(price.Text);
        string qry = "update tbl_cart set qnty='" + qnty.Text + "',total=" + Convert.ToInt32(tot) + " where cart_Id=" + id;
        cmd = new SqlCommand(qry, con);
        cmd.ExecuteNonQuery();

        grd_v.EditIndex = -1;
        showgrid();

        //Response.Redirect("display_cart.aspx");
    }
    void showgrid()
    {
       /* int id = Convert.ToInt32(Session["id"].ToString());
        String qry1 = "select first_name from tbl_registration where r_Id=" + id;
        da1 = new SqlDataAdapter(qry1, con);
        dt = new DataTable();
        da1.Fill(dt);
        String nm = dt.Rows[0][0].ToString();
       // DataTable dt = new DataTable();
        string qry = "select * from tbl_cart where cust_nm='" + nm + "'";
        da = new SqlDataAdapter(qry, con);
        da.Fill(dt);

        grd_v.DataSource = dt;
        grd_v.DataBind();
        */
        int id = Convert.ToInt32(Session["id"].ToString());
        String qry1 = "select first_name from tbl_registration where r_Id=" + id;
        da1 = new SqlDataAdapter(qry1, con);
        dt = new DataTable();
        da1.Fill(dt);
        String nm = dt.Rows[0][0].ToString();
        string qry = "select * from tbl_cart where cust_nm='" + nm + "'";
        da = new SqlDataAdapter(qry, con);
        DataTable dt1 = new DataTable();
        da.Fill(dt1);

        grd_v.DataSource = dt1;
        grd_v.DataBind();
       
        //Response.Redirect("display_cart.aspx");
    }
    protected void grd_v_SelectedIndexChanged1(object sender, EventArgs e)
    {

    }
}
