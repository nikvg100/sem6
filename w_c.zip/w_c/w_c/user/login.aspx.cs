﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace w_c.user
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            le1.Visible = false;
            le2.Visible = false;

            if (Session["user"] != null)
                Response.Redirect("/user/order.aspx");

        }

        protected void Btn1_Click(object sender, EventArgs e)
        {
string s = ConfigurationManager.ConnectionStrings["nik"].ConnectionString;
        SqlConnection con = new SqlConnection(s);
        con.Open();
        SqlCommand cmd = con.CreateCommand();
        cmd.CommandType = CommandType.Text;
        cmd.CommandText = "select * from reg where user_nm='" + tx1.Text + "'and password='" + tx2.Text + "'";
        SqlDataReader dr = cmd.ExecuteReader();
        if (dr.Read())
        {
            Session["user"] = dr["user_nm"].ToString();
            Response.Redirect("/user/home.aspx");
            le2.Visible = true;
            le2.Text = "loged in";

        }
        else
        {
            le1.Visible = true;
            le1.Text = "user name and password are not exsist";
        }
        con.Close();
    }
        }
    }
