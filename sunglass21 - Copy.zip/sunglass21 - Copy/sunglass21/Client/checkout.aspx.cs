﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
using System.Web.Configuration;

public partial class Client_checkout : System.Web.UI.Page
{
    public SqlConnection con;
    public SqlCommand cmd,cmd1;
    public SqlDataAdapter da;
    public DataTable dt;
    
   
    public DateTime date;
    public int price;
    public int  cart_Id;
    string qnty,s_Id,add, no,tot;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["emlid"] == null || Session["pass"] == null)
        {

            Response.Redirect("login.aspx");
        }
        string con_string = WebConfigurationManager.ConnectionStrings["conn"].ConnectionString;
        con = new SqlConnection(con_string);
        con.Open();
       // string pnm = Request.QueryString["id"].ToString();
         cart_Id = Convert.ToInt32(Request.QueryString["id"].ToString());
        String qry = "select * from tbl_cart where cart_Id=" + cart_Id;
        da = new SqlDataAdapter(qry, con);
        dt = new DataTable();
        da.Fill(dt);
        cart_Id = Convert.ToInt32(dt.Rows[0][0].ToString());
       //txt_pnm.Text = dt.Rows[0][1].ToString();
        txt_nm.Text = dt.Rows[0][2].ToString();
         qnty = dt.Rows[0][6].ToString();
         s_Id = dt.Rows[0][7].ToString();
         tot = dt.Rows[0][10].ToString();
        price = Convert.ToInt32(dt.Rows[0][3].ToString());
        Image1.ImageUrl = "~/img/" + dt.Rows[0][5].ToString();
      // Image1.ImageUrl =  dt.Rows[0][5].ToString();
       //Response.Write("<script>alert('" + dt.Rows[0][5].ToString() + "');</script>");
       
        date = DateTime.Today.Date;
        txt_dt.Text = date.ToString();

        
       
        
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        //Response.Redirect("My Bill.aspx");

    }
    protected void Button1_Click1(object sender, EventArgs e)
    {
      
        String nm = Session["usr"].ToString();
        //int qty = Convert.ToInt32(txt_qty.Text);
        //tot = qty * price;

        string rdb;
        if (rdb_cod.Checked == true)
        {
            rdb = rdb_cod.Text;
           
            add = txt_add.Text;
            no = txt_no.Text;

            String qry = "insert into tbl_order(s_Id,cust_nm,order_date,total_payment,payment_method,address,contact_no,qty,card_holder,card_number,expiry_date,cvv_no)values(" + s_Id + ",'" + nm + "','" + date + "','" + tot + "','" + rdb + "','" + add + "','" + no + "','" + qnty + "','0','0','0','0')";
            cmd = new SqlCommand(qry, con);
            cmd.ExecuteNonQuery();
            
            string delete = "delete from tbl_cart where cart_Id=" + cart_Id;
            cmd1 = new SqlCommand(delete, con);
            cmd1.ExecuteNonQuery();
            Response.Write("<script> alert('Successfully Cash On  Payment....Thank You'); </script>");
            Response.Redirect("Home.aspx");

        }
        else
        {
          
            rdb = rdb_cc.Text;
            
            Response.Redirect("credit_payment.aspx?id="+cart_Id+" &add="+txt_add.Text+" &no= "+txt_no.Text);
            
        }

       
        /*int id=Convert.ToInt32
        string qry = "insert into tbl_bill(order_id,cust_nm,pro_id,total_payment,payment_type) values("++",'"+nm+"',"+pid+","+qty+",'"++"'*/

        //Response.Redirect("Thanksorder.aspx");

    }


   /* protected void txt_qty_TextChanged(object sender, EventArgs e)
    {
        int qty = Convert.ToInt32(txt_qty.Text);
        tot = qty * price;
        //lbl_total.Text = tot.ToString();
    }
    protected void txt_qty_DataBinding(object sender, EventArgs e)
    {
        int qty = Convert.ToInt32(txt_qty.Text);
        tot = qty * price;
        //lbl_total.Text = tot.ToString();
    }*/
   /* protected void rdb_cod_CheckedChanged(object sender, EventArgs e)
    {
        if (rdb_cod.Checked == true)
        {


            TextBox1.Enabled = false;
            TextBox2.Enabled = false;
            TextBox3.Enabled = false;
            TextBox4.Enabled = false;
        }
         
    }
    protected void rdb_cc_CheckedChanged(object sender, EventArgs e)
    {
        if (rdb_cc.Checked == true)
        {


            TextBox1.Enabled = true;
            TextBox2.Enabled = true;
            TextBox3.Enabled = true;
            TextBox4.Enabled = true;
        }
    }*/
}
