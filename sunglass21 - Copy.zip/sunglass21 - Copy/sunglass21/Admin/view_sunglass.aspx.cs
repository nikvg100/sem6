﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
using System.Web.Configuration;

public partial class Admin_view_sunglass : System.Web.UI.Page
{
    public SqlConnection con;
    public SqlCommand cmd;
    public SqlDataAdapter da;
    public string path, image;

    protected void Page_Load(object sender, EventArgs e)
    {
        string con_string = WebConfigurationManager.ConnectionStrings["conn"].ConnectionString;
        con = new SqlConnection(con_string);
        con.Open();

        if (!IsPostBack)
        {
            showgrid();
        }
    }

    void showgrid()
    {
        DataTable dt = new DataTable();
        string qry = "select s.*,c.* from tbl_sunglass s,tbl_company c where s.c_Id=c.c_Id";
        da = new SqlDataAdapter(qry, con);
        da.Fill(dt);

        grd_v.DataSource = dt;
        grd_v.DataBind();
    }
    protected void grd_v_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        string id = grd_v.DataKeys[e.RowIndex].Values[0].ToString();
        int i = Convert.ToInt32(grd_v.DataKeys[e.RowIndex].Values[0]);

        string qry = "DELETE FROM tbl_sunglass WHERE s_Id='" + id + "'";
        cmd = new SqlCommand(qry, con);
        cmd.ExecuteNonQuery();
        showgrid();

        con.Close();
        con.Dispose();
    }
    protected void grd_v_RowEditing(object sender, GridViewEditEventArgs e)
    {
        grd_v.EditIndex = e.NewEditIndex;
        showgrid();
    }
    protected void grd_v_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        Label id = grd_v.Rows[e.RowIndex].FindControl("lbl_id") as Label;
        TextBox nm = grd_v.Rows[e.RowIndex].FindControl("txt_nm") as TextBox;
        
        TextBox price = grd_v.Rows[e.RowIndex].FindControl("txt_price") as TextBox;
        TextBox desc = grd_v.Rows[e.RowIndex].FindControl("txt_desc") as TextBox;
       
       
       // TextBox stock = grd_v.Rows[e.RowIndex].FindControl("txt_stock") as TextBox;
       
        //TextBox image = grd_v.Rows[e.RowIndex].FindControl("txt_image") as TextBox;

        FileUpload file = grd_v.Rows[e.RowIndex].FindControl("fileupld") as FileUpload;
        if (file.HasFile == true)
        {
            if (file.PostedFile.ContentType == "image/jpg" || file.PostedFile.ContentType == "image/jpeg" || file.PostedFile.ContentType == "image/png")
            {
                path = Server.MapPath("~/img/");
                image = file.PostedFile.FileName;
                file.SaveAs(path + image);
            }
        }

        //TextBox catnm=grd_v.Rows[e.RowIndex].FindControl("txt_catnm") as TextBox;
        DropDownList ddl = grd_v.Rows[e.RowIndex].FindControl("ddl_1") as DropDownList;
        DropDownList drpgender = grd_v.Rows[e.RowIndex].FindControl("DropDownList1") as DropDownList;
        
        string qry = "update tbl_sunglass set type='" + nm.Text + "',gender='" + drpgender.SelectedValue + "',price=" + Convert.ToInt32(price.Text) + ",description='" + desc.Text + "',image='" + image + "',c_Id=" + ddl.SelectedValue + " where s_Id=" + Convert.ToInt32(id.Text);
        cmd = new SqlCommand(qry, con);
        cmd.ExecuteNonQuery();
     
        grd_v.EditIndex = -1;
        showgrid();

        Response.Redirect("view_sunglass.aspx");
    }
    protected void grd_v_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        grd_v.PageIndex = e.NewPageIndex;
        showgrid();
    }
    protected void grd_v_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        grd_v.EditIndex = -1;
        showgrid();
    }
    /*protected void grd_v_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if(e.Row.RowType==DataControlRowType.DataRow)
        {
            string con_string = WebConfigurationManager.ConnectionStrings["conn"].ConnectionString;
            con = new SqlConnection(con_string);
            
            DataSet ds = new DataSet();
            string qry1 = "select * from tbl_product";
            da1 = new SqlDataAdapter(qry1, con);
            da1.Fill(ds);

            DropDownList ddl = (DropDownList)e.Row.FindControl("ddl_1");
            
            ddl.DataTextField = ds.Tables[0].Columns["cat_nm"].ToString();
            ddl.DataValueField = ds.Tables[0].Columns["cat_nm"].ToString();
            ddl.DataSource = ds;
            ddl.DataBind();
        }

        if ((e.Row.RowState & DataControlRowState.Edit) > 0)
        {
            DropDownList ddl = new DropDownList();
            ddl = (DropDownList)e.Row.FindControl("ddl_1");

            if (ddl != null)
            {
                
                ddl.DataTextField = ds.Tables["cat"].Columns["cat_nm"].ColumnName.ToString();
                ddl.DataValueField = ds.Tables["cat"].Columns["cat_id"].ColumnName.ToString();
                ddl.DataSource = ds.Tables["cat"];
                ddl.DataBind();

                ((DropDownList)e.Row.FindControl("cat_nm")).SelectedValue = DataBinder.Eval(e.Row.DataItem,"cat_id").ToString();
            }
        }
    }*/
}