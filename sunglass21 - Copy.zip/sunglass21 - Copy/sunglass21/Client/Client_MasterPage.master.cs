﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Web.Security;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
using System.Web.Configuration;

public partial class Client_Client_MasterPage : System.Web.UI.MasterPage
{
    public SqlConnection con;
    public SqlCommand cmd;
    public SqlDataAdapter da;
    public DataTable dt;

    protected void Page_Load(object sender, EventArgs e)
    {
        string con_string = WebConfigurationManager.ConnectionStrings["conn"].ConnectionString;
        con = new SqlConnection(con_string);
        con.Open();

        if (Session["emlid"] != null || Session["pass"] != null)
        {

            Label1.Text = "Welcome:" + Session["usr"].ToString();
            cmd = new SqlCommand("select count(*) from tbl_cart where r_Id=" + Session["id"].ToString(), con);
            int c = Convert.ToInt32(cmd.ExecuteScalar());
            Label2.Text = "("+c.ToString()+")";
           
        }
        else
        {
            Label1.Text = "Welcome";
            Label2.Text = "";
        }

    }

    
}
