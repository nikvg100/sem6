﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
using System.Web.Configuration;

public partial class Client_login : System.Web.UI.Page
{
    public SqlConnection con;
    public SqlDataAdapter da;
    public DataTable dt;
    protected void Page_Load(object sender, EventArgs e)
    {
        String con_string = WebConfigurationManager.ConnectionStrings["conn"].ConnectionString;
        con = new SqlConnection(con_string);
        con.Open();
    }
    protected void btn_login_Click(object sender, EventArgs e)
    {
        string emlid, password;

        emlid = txt_emailid.Text;
        password = txt_password.Text;

        string qry = "select * from tbl_registration where (email='" + emlid + "') and password='" + password + "'";
        da = new SqlDataAdapter(qry, con);
        DataTable dt = new DataTable();
        da.Fill(dt);

        if (dt.Rows.Count == 0)
        {
            Response.Redirect("login.aspx");
            Response.Write("Email ID or Password is wrong..");
        }
        else
        {
            String qry1 = "select first_name from tbl_registration where email ='" + emlid + "'";
            da = new SqlDataAdapter(qry1, con);
            da.Fill(dt);
            String user = dt.Rows[0][2].ToString();
            Session["usr"] = user.ToString();

            int id = Convert.ToInt32(dt.Rows[0][0].ToString());
            Session["id"] = id.ToString();

            Session["emlid"] = txt_emailid.Text;
            Session["pass"] = txt_password.Text;
          
            Response.Redirect("Home.aspx");
           
        }
    }
}