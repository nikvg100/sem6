﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
using System.Web.Configuration;

public partial class Client_checkout : System.Web.UI.Page
{
    public SqlConnection con;
    public SqlCommand cmd;
    public SqlDataAdapter da;
    public DataTable dt;
    
   
    protected void Page_Load(object sender, EventArgs e)
    {
        string con_string = WebConfigurationManager.ConnectionStrings["conn"].ConnectionString;
        con = new SqlConnection(con_string);
        con.Open();
        if (Session["user_nm"] == null || Session["pass"] == null)
        {

            Response.Redirect("login.aspx");
        }
        
    }
    
    protected void Button1_Click1(object sender, EventArgs e)
    {
      
       // String nm = Session["usr"].ToString();
        //int qty = Convert.ToInt32(txt_qty.Text);
        //tot = qty * price;


        string qry = "insert into ord (w_no,full_nm,addr,city,state,pincode,email,mobile,qty) values(" + t1.Text + ",'" + t3.Text + "','" + t_add.Text + "','" + t4.Text + "','" + t5.Text + "','" + t6.Text + "','" + t7.Text + "','" + t8.Text + "','" + t2.Text + "')";
        cmd = new SqlCommand(qry, con);
        cmd.ExecuteNonQuery();

       
            Response.Write("<script> alert('SuccessfullyCash On  Payment....Thank You get details of order in Your wattsapp '); </script>");
            Response.Redirect("Home.aspx");

        
       
      

    }


   /* protected void txt_qty_TextChanged(object sender, EventArgs e)
    {
        int qty = Convert.ToInt32(txt_qty.Text);
        tot = qty * price;
        //lbl_total.Text = tot.ToString();
    }
    protected void txt_qty_DataBinding(object sender, EventArgs e)
    {
        int qty = Convert.ToInt32(txt_qty.Text);
        tot = qty * price;
        //lbl_total.Text = tot.ToString();
    }*/
   /* protected void rdb_cod_CheckedChanged(object sender, EventArgs e)
    {
        if (rdb_cod.Checked == true)
        {


            TextBox1.Enabled = false;
            TextBox2.Enabled = false;
            TextBox3.Enabled = false;
            TextBox4.Enabled = false;
        }
         
    }
    protected void rdb_cc_CheckedChanged(object sender, EventArgs e)
    {
        if (rdb_cc.Checked == true)
        {


            TextBox1.Enabled = true;
            TextBox2.Enabled = true;
            TextBox3.Enabled = true;
            TextBox4.Enabled = true;
        }
    }*/
}
