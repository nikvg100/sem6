﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

public partial class admin_Login : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        l1.Visible = false;
        l2.Visible = false;
      
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
         string s = ConfigurationManager.ConnectionStrings["nik"].ConnectionString;
        SqlConnection con = new SqlConnection(s);
        con.Open();
        SqlCommand cmd = con.CreateCommand();
        cmd.CommandType = CommandType.Text;
        cmd.CommandText = "select * from admin where ad_name='" + t1.Text + "'and pass='" + t2.Text + "'";
        SqlDataReader dr = cmd.ExecuteReader();
        if (dr.Read())
        {
           Session["adminuser"] = dr["ad_name"].ToString();
           Response.Redirect("/admin/adminhome.aspx");
            l2.Visible = true;
            l2.Text = "loged in";

        }
        else {
            l1.Visible = true;
        l1.Text="user name and password are not exsist";}
        con.Close();
    }

}  