﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
using System.Web.Configuration;

public partial class Admin_view_feedback : System.Web.UI.Page
{
    public SqlConnection con;
    public SqlCommand cmd;
    public SqlDataAdapter da;

    protected void Page_Load(object sender, EventArgs e)
    {
        string con_string = WebConfigurationManager.ConnectionStrings["conn"].ConnectionString;
        con = new SqlConnection(con_string);
        con.Open();

        if (!IsPostBack)
        {
            showgrid();
        }
        
    }
    void showgrid()
    {
        DataTable dt = new DataTable();
        string qry = "select * from cont";
        da = new SqlDataAdapter(qry, con);
        da.Fill(dt);

        grd_v.DataSource = dt;
        grd_v.DataBind();
    }
    protected void grd_v_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        grd_v.PageIndex = e.NewPageIndex;
        showgrid();
    }
    protected void grd_v_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        string id = grd_v.DataKeys[e.RowIndex].Values[0].ToString();
        int i = Convert.ToInt32(grd_v.DataKeys[e.RowIndex].Values[0]);

        cmd = new SqlCommand("DELETE FROM cont WHERE Id='" + id + "'", con);
        cmd.ExecuteNonQuery();
        showgrid();

        con.Close();
        con.Dispose();
    }
    
}
