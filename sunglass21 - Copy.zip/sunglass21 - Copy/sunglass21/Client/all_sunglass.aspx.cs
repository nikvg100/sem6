﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
using System.Web.Configuration;

public partial class Client_male : System.Web.UI.Page
{

    public SqlConnection con;
    public SqlDataAdapter da;
    public DataTable dt;
    public string qry;

    protected void Page_Load(object sender, EventArgs e)
    {
        string cn_str = WebConfigurationManager.ConnectionStrings["conn"].ConnectionString;
        con = new SqlConnection(cn_str);
        con.Open();

        if (!IsPostBack)
       {
            String qry = "select s.*,c.* from tbl_sunglass s,tbl_company c where c.c_Id=s.c_Id";
            dt = new DataTable();
            da = new SqlDataAdapter(qry, con);
            da.Fill(dt);

            DataList1.DataSource = dt;
            DataList1.DataBind();
            DropDownList1.Items.Insert(0, "select");
          //  DropDownList2.Items.Insert(0, "select");
            DropDownList3.Items.Insert(0, "select");
            DropDownList1.Enabled = false;
           // DropDownList2.Enabled = false;
            DropDownList3.Enabled = false;
            Button2.Enabled = false;

       }
       
    }

/* protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        DataTable dt1 = new DataTable();
        SqlDataAdapter da1 = new SqlDataAdapter();
        String c_Id = DropDownList1.SelectedValue;
       
        String type = DropDownList2.SelectedValue;
        String gender = DropDownList3.SelectedValue;
       // DropDownList2.Items.Insert(0,"select");
       /* if (CheckBox1.Checked == true || CheckBox2.Checked == true || CheckBox3.Checked == true)
        {
            Response.Write("<script> alert('please');</script>");
        }
      
        if (CheckBox1.Checked == true)
        {

            qry = "select s.*,c.* from tbl_sunglass s,tbl_company c where c.c_Id=s.c_Id and s.c_Id='" + c_Id + "'";
        }
       else (CheckBox1.Checked == false)
        {
            DropDownList1.Enabled = false;
        }
       
       
        if (CheckBox2.Checked == true)
        {
            qry = "select s.*,c.* from tbl_sunglass s,tbl_company c where c.c_Id=s.c_Id and s.type='" + type + "'";
        }
        if (CheckBox3.Checked == true)
        {
            qry = "select s.*,c.* from tbl_sunglass s,tbl_company c where c.c_Id=s.c_Id and s.gender='" + gender + "'";
        }
        if (CheckBox1.Checked == true && CheckBox2.Checked == true && CheckBox3.Checked == true)
        {
            qry = "select s.*,c.* from tbl_sunglass s,tbl_company c where c.c_Id=s.c_Id and s.type='" + type + "' and s.c_Id='" + c_Id + "' and s.gender='" + gender + "'";

        }
        if (CheckBox1.Checked == true && CheckBox2.Checked == true)
        {
            qry = "select s.*,c.* from tbl_sunglass s,tbl_company c where c.c_Id=s.c_Id and s.type='" + type + "' and s.c_Id='" + c_Id + "' ";

        }
        if (CheckBox1.Checked == true && CheckBox3.Checked == true)
        {
            qry = "select s.*,c.* from tbl_sunglass s,tbl_company c where c.c_Id=s.c_Id and s.c_Id='" + c_Id + "' and s.gender='" + gender + "'";

        }
        if (CheckBox2.Checked == true && CheckBox3.Checked == true)
        {
            qry = "select s.*,c.* from tbl_sunglass s,tbl_company c where c.c_Id=s.c_Id and s.type='" + type + "' and s.gender='" + gender + "'";

        }
        dt1 = new DataTable();
        da1 = new SqlDataAdapter(qry, con);
        da1.Fill(dt1);

        DataList1.DataSource = dt1;
        DataList1.DataBind();


    }*/
   
    protected void Button1_Click(object sender, EventArgs e)
    {
        DropDownList1.Enabled = true;
      //  DropDownList2.Enabled = true;
        DropDownList3.Enabled = true;
        Button2.Enabled = true;
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
         DataTable dt1 = new DataTable();
        SqlDataAdapter da1 = new SqlDataAdapter();
        String c_Id = DropDownList1.SelectedValue;
       
       // String type = DropDownList2.SelectedValue;
        String gender = DropDownList3.SelectedValue;
        qry = "select s.*,c.* from tbl_sunglass s,tbl_company c where c.c_Id=s.c_Id and s.c_Id='" + c_Id + "' and s.gender='" + gender + "'";
        dt1 = new DataTable();
        da1 = new SqlDataAdapter(qry, con);
        da1.Fill(dt1);

        DataList1.DataSource = dt1;
        DataList1.DataBind();


      /*  if (CheckBox1.Checked == true)
        {

            qry = "select s.*,c.* from tbl_sunglass s,tbl_company c where c.c_Id=s.c_Id and s.c_Id='" + c_Id + "'";
        }
       
       
        if (CheckBox2.Checked == true)
        {
            qry = "select s.*,c.* from tbl_sunglass s,tbl_company c where c.c_Id=s.c_Id and s.type='" + type + "'";
        }
        if (CheckBox3.Checked == true)
        {
            qry = "select s.*,c.* from tbl_sunglass s,tbl_company c where c.c_Id=s.c_Id and s.gender='" + gender + "'";
        }*/
       // if (CheckBox1.Checked == true && CheckBox2.Checked == true && CheckBox3.Checked == true)
       // {
           // qry = "select s.*,c.* from tbl_sunglass s,tbl_company c where c.c_Id=s.c_Id and s.type='" + type + "' and s.c_Id='" + c_Id + "' and s.gender='" + gender + "'";

        //}
        /*if (CheckBox1.Checked == true && CheckBox2.Checked == true)
        {
            qry = "select s.*,c.* from tbl_sunglass s,tbl_company c where c.c_Id=s.c_Id and s.type='" + type + "' and s.c_Id='" + c_Id + "' ";

        }
        if (CheckBox1.Checked == true && CheckBox3.Checked == true)
        {
            qry = "select s.*,c.* from tbl_sunglass s,tbl_company c where c.c_Id=s.c_Id and s.c_Id='" + c_Id + "' and s.gender='" + gender + "'";

        }
        if (CheckBox2.Checked == true && CheckBox3.Checked == true)
        {
            qry = "select s.*,c.* from tbl_sunglass s,tbl_company c where c.c_Id=s.c_Id and s.type='" + type + "' and s.gender='" + gender + "'";

        }*/
       

    }
}
