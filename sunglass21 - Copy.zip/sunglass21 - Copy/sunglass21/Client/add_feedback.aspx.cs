﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
using System.Web.Configuration;

public partial class Client_add_feedback : System.Web.UI.Page
{
    public SqlConnection con;
    public SqlCommand cmd;
    public SqlDataAdapter da;
    protected void Page_Load(object sender, EventArgs e)
    {
        string con_string = WebConfigurationManager.ConnectionStrings["conn"].ConnectionString;
        con = new SqlConnection(con_string);
        con.Open();
    }
    protected void btn_submit_Click(object sender, EventArgs e)
    {
        string nm, eml, feedback,remark;

        nm = txt_nm.Text;
        eml = txt_eml.Text;
        feedback = txt_feedback.Text;
       

        string qry = "insert into tbl_feedback(f_name,f_email_id,feedback) values('"+nm+"','"+eml+"','"+feedback+"')";
        cmd = new SqlCommand(qry, con);
        cmd.ExecuteNonQuery();

        Response.Write("<script> alert('Record Send Successfully');</script>");
        Response.Redirect("Home.aspx");
      
  

    }
}