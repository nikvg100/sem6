﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;


namespace w_c.user
{
    public partial class contect : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            l1.Visible = false;
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            string connectionString = ConfigurationManager.ConnectionStrings["nik"].ConnectionString.ToString();
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                con.Open();

                using (SqlCommand cmd = con.CreateCommand())
                {
                    cmd.CommandType = CommandType.Text;
                    cmd.CommandText = "INSERT INTO cont VALUES(@t1, @t2, @t3, @t4)";

                    // Use parameters to prevent SQL injection
                    cmd.Parameters.AddWithValue("@t1", t1.Text);
                    cmd.Parameters.AddWithValue("@t2", t2.Text);
                    cmd.Parameters.AddWithValue("@t3", t3.Text);
                    cmd.Parameters.AddWithValue("@t4", t4.Text);
                  

                    cmd.ExecuteNonQuery();

                }
                con.Close();
                // Set the text after the database operation
                l1.Visible = true;
                l1.Text = "You Request successfully Submited We Contect You Soon...";
                t1.Text = "";
                t2.Text = "";
                t3.Text = "";
                t4.Text = "";

            }
   
        
        }
    }
}