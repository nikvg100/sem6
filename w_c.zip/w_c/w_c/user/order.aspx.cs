﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

namespace w_c.user
{
    public partial class order : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            l1.Visible = false;

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            string connectionString = ConfigurationManager.ConnectionStrings["nik"].ConnectionString.ToString();
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                con.Open();

                using (SqlCommand cmd = con.CreateCommand())
                {
                    cmd.CommandType = CommandType.Text;
                    cmd.CommandText = "INSERT INTO ord (w_no,full_nm,[add],city,state,pincode,email,mobile,qty) VALUES(@t1, @t2, @t3, @t4, @t5, @t6, @t7,@t8,@t9)";

                    // Use parameters to prevent SQL injection
                    cmd.Parameters.AddWithValue("@t1", t1.Text);
                    cmd.Parameters.AddWithValue("@t2", t2.Text);
                    cmd.Parameters.AddWithValue("@t3", t3.Text);
                    cmd.Parameters.AddWithValue("@t4", t4.Text);
                    cmd.Parameters.AddWithValue("@t5", t5.Text);
                    cmd.Parameters.AddWithValue("@t6", t6.Text);
                    cmd.Parameters.AddWithValue("@t7", t7.Text);
                    cmd.Parameters.AddWithValue("@t8", t8.Text);
                    cmd.Parameters.AddWithValue("@t9", t9.Text);


                    cmd.ExecuteNonQuery();

                }
                con.Close();
                // Set the text after the database operation
                l1.Visible = true;
                l1.Text = " Thank You ,Your Order is Successfully Submited our Team contect you in Wattsapp/Email </br> provide you all details";
                t1.Text = "";
                t2.Text = "";
                t3.Text = "";
                t4.Text = "";
                t5.Text = "";
                t6.Text = "";
                t7.Text = "";
                t8.Text = "";
                t9.Text = "";


            }


        }

        protected void Button3_Click(object sender, EventArgs e)
        {
            t1.Text = "";
            t2.Text = "";
            t3.Text = "";
            t4.Text = "";
            t5.Text = "";
            t6.Text = "";
            t7.Text = "";
            t8.Text = "";
        }
    }
}