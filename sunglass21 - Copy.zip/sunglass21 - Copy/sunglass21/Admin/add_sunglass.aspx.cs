﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Web.Configuration;
using System.Data;
using System.Configuration;

public partial class Admin_add_product : System.Web.UI.Page
{
    public SqlConnection con;
    public SqlCommand cmd;
    public SqlDataAdapter da;
    public string path, image;

    protected void Page_Load(object sender, EventArgs e)
    {
        string con_string = WebConfigurationManager.ConnectionStrings["conn"].ConnectionString;
        con = new SqlConnection(con_string);
        con.Open();

        string qry = "select * from tbl_company";
        da = new SqlDataAdapter(qry, con);
        DataTable dt = new DataTable();
        da.Fill(dt);

        ddl_1.DataTextField = "c_name";
        ddl_1.DataValueField = "c_Id";
        ddl_1.DataSource = dt;
        ddl_1.DataBind();
        ddl_1.Items.Insert(0, new ListItem("--Select--",""));
        //ddl_1.SelectedIndex = "";
    }
    protected void btn_add_Click(object sender, EventArgs e)
    {
        string nm, desc,gender;
        int price, comnm;

        nm = txt_pronm.Text;
        comnm = Convert.ToInt32(ddl_1.SelectedValue);
       // comnm = ddl_1.SelectedValue;
        desc = txt_prodesc.Text;
        gender = DropDownList1.SelectedValue;
        price = Convert.ToInt32(txt_proprice.Text);
       
      

        /* if (file_upld.HasFile == true)
         {
             if (file_upld.PostedFile.ContentType == "image/jpg" || file_upld.PostedFile.ContentType == "image/jpeg")
             {
                 path = Server.MapPath("~/img/");
                 image = file_upld.PostedFile.FileName;
                 file_upld.SaveAs(path + image);
             }
         }*/

        if (file_upld.HasFile)
         {
            
             file_upld.SaveAs(Server.MapPath("~/img/"+file_upld.FileName));
             image = file_upld.FileName;

         }
        
        string qry = "insert into tbl_sunglass(type,description,price,image,c_Id,gender) values('" + nm + "','" + desc + "'," + price + ",'" + image + "'," + comnm + ",'" + gender + "')";
        cmd = new SqlCommand(qry, con);
        cmd.ExecuteNonQuery();

        Response.Write("<script> alert('Record Inserted Successfully');</script>");

        ddl_1.SelectedValue = "";
       // Response.Redirect("view_sunglass.aspx");
       
    }
}
