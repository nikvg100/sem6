﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
using System.Web.Configuration;

public partial class Client_detail : System.Web.UI.Page
{
    public SqlConnection con;
    public SqlDataAdapter da;
    public SqlCommand cmd;
    public DataTable dt;
    public int price;
    public int tot;

    protected void Page_Load(object sender, EventArgs e)
    {
         string con_string = WebConfigurationManager.ConnectionStrings["conn"].ConnectionString;
        con = new SqlConnection(con_string);
        con.Open();

        string sid = Request.QueryString["sid"].ToString();
       // int s_id = Convert.ToInt32(Request.QueryString["sid"].ToString());
        //string id=Session["pid"].ToString();
        string qry = "select * from tbl_sunglass where s_Id='" + sid+"'";
        da = new SqlDataAdapter(qry,con);
        DataTable dt = new DataTable();
        da.Fill(dt);
       
        image.ImageUrl = "~/img/"+dt.Rows[0][4].ToString();
        lbl_type.Text = dt.Rows[0][1].ToString();
      
        lbl_desc.Text=dt.Rows[0][2].ToString();
        lbl_price.Text=dt.Rows[0][3].ToString();
        
        }
    protected void Button1_Click(object sender, EventArgs e)
    {
       
        if (Session["emlid"] == null || Session["pass"]==null)
        {
           
            Response.Redirect("login.aspx");
        }
        else
        {

            
            string eml = Session["emlid"].ToString();
            string qry = "select r_Id,first_name from tbl_registration where email ='" + eml + "' ";
            da = new SqlDataAdapter(qry,con);
            DataTable dt2 = new DataTable();
            da.Fill(dt2);

            
            string r_Id = dt2.Rows[0][0].ToString();
           
           string nm = dt2.Rows[0][1].ToString();
            string id = Request.QueryString["sid"].ToString();


            string desc, stock, image, type, gender, qunty,price;
            string qry2 = "select s.*,c.* from tbl_sunglass s,tbl_company c where s_Id='"+id+"' and s.c_Id=c.c_Id";
           
            da = new SqlDataAdapter(qry2,con);
            DataTable dt1 = new DataTable();
            da.Fill(dt1);
          string  c_Id = dt1.Rows[0][5].ToString();
          
           price = dt1.Rows[0][3].ToString();
            desc = dt1.Rows[0][2].ToString();
           // stock = dt1.Rows[0][5].ToString();
            gender = dt1.Rows[0][6].ToString();
            int a=Convert.ToInt32(price);
            int b = Convert.ToInt32(txt_qnty.Text);
            int c = a * b;
           
            image =  dt1.Rows[0][4].ToString();
            type = dt1.Rows[0][1].ToString();
            
            string q3 = "select c_name from tbl_company where c_Id='"+c_Id+"'";
            da = new SqlDataAdapter(q3, con);
            DataTable dt3 = new DataTable();
            da.Fill(dt3);
            string c_nm = dt3.Rows[0][0].ToString();

            string qry1 = "insert into tbl_cart (cust_nm,s_type,s_price,s_desc,s_image,qnty,s_Id,r_Id,s_gender,total,c_nm) values('" + nm + "','" + type + "','" + price + "','" + desc + "','" + image + "','" + txt_qnty.Text + "','" + id + "', '" + r_Id + "', '" + gender + "', "+c+",'"+c_nm+"')";
            cmd = new SqlCommand(qry1,con);
                cmd.ExecuteNonQuery();
            //int id = Convert.ToInt32(Request.QueryString["pid"].ToString());



                Response.Redirect("display_cart.aspx");
            //Response.Redirect("My Cart.aspx?pid=" + id);
        }
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        Response.Redirect("Home.aspx");
    }
}
    
