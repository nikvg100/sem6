﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Web.Configuration;

public partial class admin_login : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection();
    SqlDataAdapter da = new SqlDataAdapter();

    protected void Page_Load(object sender, EventArgs e)
    {

    }
    
    protected void b1_Click(object sender, EventArgs e)
    {
        string con_string = WebConfigurationManager.ConnectionStrings["conn"].ConnectionString;
        con = new SqlConnection(con_string);
        con.Open();
        SqlCommand cmd = new SqlCommand("select count(Id) from Admin_login where Admin_name='" + t1.Text + "' and Password='" + t2.Text + "'", con);
        //da = new SqlDataAdapter("select count(Id) from Admin_login where Admin_name='"+t1.Text +"' and Password='"+t2.Text+"'",con);
        //DataSet ds = new DataSet();
        //da.Fill(ds);
        //int x=ds.Tables[0].Rows.Count;
        int x = (int)cmd.ExecuteScalar();
        Response.Write("Value of x is " + x);
        //string u;
        //string p;
        //u = ds.Tables[0].Rows[0]["Admin_name"].ToString();
        ///p = ds.Tables[0].Rows[0]["Password"].ToString();
        //if(u==t1.Text && p==t2.Text)
        if(x==1)
        {
            Session["admin_nm"] = t1.Text;
            Response.Redirect("home.aspx");
        }
        else
        {
            Response.Redirect("admin_login.aspx");
        }
    }
}