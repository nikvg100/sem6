﻿
Partial Class Client_man
    Inherits System.Web.UI.Page

End Class
